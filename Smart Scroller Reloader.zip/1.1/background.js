const ALARM_PREFIX = "reloader_"; // Use a prefix to manage multiple alarms

function getRandomInRange(min, max) {
  if (min > max) [min, max] = [max, min];
  return Math.random() * (max - min) + min;
}

// Schedules a reload for a SPECIFIC tab
function scheduleReload(settings) {
  const alarmName = ALARM_PREFIX + settings.tabId;
  if (settings.mode === 'automate') {
    const randomDelay = getRandomInRange(settings.minTime, settings.maxTime);
    chrome.alarms.create(alarmName, { delayInMinutes: randomDelay });
    console.log(`Tab ${settings.tabId} will reload in ${randomDelay.toFixed(2)} minutes.`);
  } else { // Fixed mode
    chrome.alarms.create(alarmName, { periodInMinutes: settings.time });
    console.log(`Tab ${settings.tabId} will reload every ${settings.time} minutes.`);
  }
}

// Main message listener from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "startReloading") {
    const alarmName = ALARM_PREFIX + request.tabId;
    // Store the settings for this specific tab's alarm
    chrome.storage.local.set({ [alarmName]: request }, () => {
      scheduleReload(request);
    });
  } else if (request.action === "stopReloading") {
    // A general stop command should clear ALL reloading alarms
    chrome.alarms.getAll(alarms => {
      const reloadAlarms = alarms.filter(alarm => alarm.name.startsWith(ALARM_PREFIX));
      reloadAlarms.forEach(alarm => {
        chrome.alarms.clear(alarm.name);
        chrome.storage.local.remove(alarm.name); // Clean up storage
        console.log(`Cleared reload alarm: ${alarm.name}`);
      });
    });
  }
});

// The listener for when any alarm fires
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return; // Ignore other alarms

  const tabId = parseInt(alarm.name.replace(ALARM_PREFIX, ""));

  try {
    // Check if the tab still exists before trying to reload
    await chrome.tabs.get(tabId);
    
    // If it exists, reload it
    chrome.tabs.reload(tabId, { bypassCache: true }); // bypassCache ensures a fresh load
    console.log(`Reloaded tab: ${tabId}`);

    // For automated mode, we need to schedule the NEXT reload
    const settings = await chrome.storage.local.get(alarm.name);
    if (settings[alarm.name] && settings[alarm.name].mode === 'automate') {
      // It's a one-off alarm, so we schedule the next one in the chain
      scheduleReload(settings[alarm.name]);
    }
    
  } catch (e) {
    // The tab was likely closed. Clean up the alarm and storage.
    console.log(`Tab ${tabId} not found. Clearing its alarm.`);
    chrome.alarms.clear(alarm.name);
    chrome.storage.local.remove(alarm.name);
  }
});