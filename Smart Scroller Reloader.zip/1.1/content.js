let scrollInterval;
let pauseTimeout;
let resumeTimeout;

function getRandomInRange(min, max) {
  if (min > max) [min, max] = [max, min];
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function stopScrolling() {
  clearInterval(scrollInterval);
  clearTimeout(pauseTimeout);
  clearTimeout(resumeTimeout);
}

// Handles continuous scrolling
function continuousScroll(params) {
    stopScrolling();
    
    // Check if speed should be automated
    if (params.speedMode === 'automate') {
        // For automated speed, we create a loop that resets the speed at random intervals
        const changeSpeedInterval = getRandomInRange(5, 15) * 1000; // Change speed every 5-15 seconds
        
        function scrollWithChangingSpeed() {
            clearInterval(scrollInterval); // Clear old interval
            const currentSpeed = getRandomInRange(params.speedMin, params.speedMax);
            console.log(`New continuous speed: ${currentSpeed}px/s`);
            const pixelsPerFrame = currentSpeed / 60;
            let scrollPosition = window.scrollY;
            scrollInterval = setInterval(() => {
                scrollPosition += pixelsPerFrame;
                window.scrollTo(0, scrollPosition);
            }, 1000/60);
        }
        
        scrollWithChangingSpeed(); // Start first scroll
        resumeTimeout = setInterval(scrollWithChangingSpeed, changeSpeedInterval); // Set interval to change speed
        
    } else {
        // For fixed speed, just one interval is needed
        const pixelsPerFrame = params.speed / 60;
        let scrollPosition = window.scrollY;
        scrollInterval = setInterval(() => {
            scrollPosition += pixelsPerFrame;
            window.scrollTo(0, scrollPosition);
        }, 1000 / 60);
    }
}

// Handles scrolling with pauses
function scrollAndPause(params) {
  stopScrolling();
  // Determine speed for this cycle
  const currentSpeed = (params.speedMode === 'fixed')
    ? params.speed
    : getRandomInRange(params.speedMin, params.speedMax);
  // Determine pause and resume times for this cycle
  const pauseDuration = (params.pauseMode === 'fixed')
    ? params.pause
    : getRandomInRange(params.pauseMin, params.pauseMax);
  const resumeDuration = (params.pauseMode === 'fixed')
    ? params.resume
    : getRandomInRange(params.resumeMin, params.resumeMax);
    
  console.log(`Scrolling at ${currentSpeed}px/s. Pausing in ${pauseDuration}s. Resuming after ${resumeDuration}s.`);
  // Start Scrolling
  let scrollPosition = window.scrollY;
  const pixelsPerFrame = currentSpeed / 60;
  scrollInterval = setInterval(() => {
    scrollPosition += pixelsPerFrame;
    window.scrollTo(0, scrollPosition);
  }, 1000 / 60);
  // Schedule the Pause
  pauseTimeout = setTimeout(() => {
    clearInterval(scrollInterval);
    // Schedule the Resumption
    resumeTimeout = setTimeout(() => {
      scrollAndPause(params);
    }, resumeDuration * 1000);
  }, pauseDuration * 1000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "startScrolling") {
    if (request.pauseMode === 'none') {
        continuousScroll(request);
    } else {
        scrollAndPause(request);
    }
  } else if (request.action === "stopScrolling") {
    stopScrolling();
  }
});