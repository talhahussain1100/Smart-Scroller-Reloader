// --- UI TOGGLING LOGIC ---
function setupRadioToggle(radioName, options) {
  document.querySelectorAll(`input[name="${radioName}"]`).forEach(radio => {
    radio.addEventListener('change', function() {
      for (const value in options) {
        document.getElementById(options[value]).style.display = (this.value === value) ? 'block' : 'none';
      }
    });
  });
}
setupRadioToggle('scroll-speed-mode', { 'fixed': 'fixed-speed-settings', 'automate': 'automate-speed-settings' });
setupRadioToggle('pause-mode', { 'fixed': 'fixed-pause-settings', 'automate': 'automate-pause-settings', 'none': '' });
setupRadioToggle('reload-mode', { 'fixed': 'fixed-reload-settings', 'automate': 'automate-reload-settings' });

// Manually trigger the change event to set initial state
document.querySelector('input[name="pause-mode"]:checked').dispatchEvent(new Event('change'));


// --- SCROLLING LOGIC ---
document.getElementById('startScrolling').addEventListener('click', () => {
  let scrollParams = { action: "startScrolling" };
  // Speed
  scrollParams.speedMode = document.querySelector('input[name="scroll-speed-mode"]:checked').value;
  if (scrollParams.speedMode === 'fixed') {
    scrollParams.speed = parseInt(document.getElementById('scrollSpeed').value);
  } else {
    scrollParams.speedMin = parseInt(document.getElementById('speedMin').value);
    scrollParams.speedMax = parseInt(document.getElementById('speedMax').value);
  }
  // Pause
  scrollParams.pauseMode = document.querySelector('input[name="pause-mode"]:checked').value;
  if (scrollParams.pauseMode === 'fixed') {
    scrollParams.pause = parseInt(document.getElementById('pauseTime').value);
    scrollParams.resume = parseInt(document.getElementById('resumeTime').value);
  } else if (scrollParams.pauseMode === 'automate') {
    scrollParams.pauseMin = parseInt(document.getElementById('pauseMin').value);
    scrollParams.pauseMax = parseInt(document.getElementById('pauseMax').value);
    scrollParams.resumeMin = parseInt(document.getElementById('resumeMin').value);
    scrollParams.resumeMax = parseInt(document.getElementById('resumeMax').value);
  }

  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    chrome.scripting.executeScript({
      target: {tabId: tabs[0].id},
      files: ['content.js']
    }, () => {
      chrome.tabs.sendMessage(tabs[0].id, scrollParams);
    });
  });
});

document.getElementById('stopScrolling').addEventListener('click', () => {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {action: "stopScrolling"});
  });
});


// --- RELOADER LOGIC (Unchanged) ---
document.getElementById('startReloading').addEventListener('click', () => {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs.length === 0) { console.error("No active tab found."); return; }
    const targetTabId = tabs[0].id;
    let reloadParams = { action: "startReloading", tabId: targetTabId };
    reloadParams.mode = document.querySelector('input[name="reload-mode"]:checked').value;
    if (reloadParams.mode === 'fixed') {
      const mins = parseInt(document.getElementById('reloadTimeMin').value) || 0;
      const secs = parseInt(document.getElementById('reloadTimeSec').value) || 0;
      reloadParams.time = mins + (secs / 60);
    } else {
      const minMins = parseInt(document.getElementById('reloadMinMin').value) || 0;
      const minSecs = parseInt(document.getElementById('reloadMinSec').value) || 0;
      reloadParams.minTime = minMins + (minSecs / 60);
      const maxMins = parseInt(document.getElementById('reloadMaxMin').value) || 0;
      const maxSecs = parseInt(document.getElementById('reloadMaxSec').value) || 0;
      reloadParams.maxTime = maxMins + (maxSecs / 60);
    }
    if ((reloadParams.time || reloadParams.maxTime) > 0.01) {
        chrome.runtime.sendMessage(reloadParams);
        window.close();
    } else {
        alert("Please enter a reload time greater than a few seconds.");
    }
  });
});

document.getElementById('stopReloading').addEventListener('click', () => {
  chrome.runtime.sendMessage({action: "stopReloading"});
  window.close();
});